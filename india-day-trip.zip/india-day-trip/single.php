<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package India_Day_Trip
 */

get_header();
?>

<div class="breadcumb-wrapper" data-bg-src="<?php echo get_template_directory_uri(); ?>/assets/img/bg/breadcumb-bg.jpg">
    <div class="container">
        <div class="breadcumb-content">
            <h1 class="breadcumb-title"><?php the_title(); ?></h1>
            <ul class="breadcumb-menu">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <?php if (get_post_type() === 'tour') : ?>
                    <li><a href="<?php echo home_url('/tours'); ?>">Tours</a></li>
                <?php elseif (get_post_type() === 'gallery') : ?>
                    <li><a href="<?php echo home_url('/gallery'); ?>">Gallery</a></li>
                <?php else : ?>
                    <li><a href="<?php echo home_url('/blog'); ?>">Blog</a></li>
                <?php endif; ?>
                <li><?php the_title(); ?></li>
            </ul>
        </div>
    </div>
</div>

<div class="space-top space-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="single-content">
                    <?php
                    while (have_posts()) :
                        the_post();
                    ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                            <header class="entry-header">
                                <?php
                                if ('tour' === get_post_type()) :
                                    // Display tour-specific information
                                    $price = get_post_meta(get_the_ID(), 'tour_price', true);
                                    $duration = get_post_meta(get_the_ID(), 'tour_duration', true);
                                    $location = get_post_meta(get_the_ID(), 'tour_location', true);
                                ?>
                                    <div class="tour-meta">
                                        <div class="tour-price">
                                            <span class="currency">$<?php echo $price ?: 'Contact for Price'; ?></span>
                                        </div>
                                        <div class="tour-details">
                                            <span class="duration"><i class="fa-light fa-clock"></i> <?php echo $duration ?: 'Flexible'; ?></span>
                                            <span class="location"><i class="fa-light fa-map-marker-alt"></i> <?php echo $location ?: 'India'; ?></span>
                                        </div>
                                    </div>
                                <?php
                                endif;

                                the_title('<h1 class="entry-title">', '</h1>');
                                ?>
                            </header><!-- .entry-header -->

                            <?php india_day_trip_post_thumbnail(); ?>

                            <div class="entry-content">
                                <?php
                                the_content(
                                    sprintf(
                                        wp_kses(
                                            /* translators: %s: Name of current post. Only visible to screen readers */
                                            __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'india-day-trip'),
                                            array(
                                                'span' => array(
                                                    'class' => array(),
                                                ),
                                            )
                                        ),
                                        wp_kses_post(get_the_title())
                                    )
                                );

                                wp_link_pages(
                                    array(
                                        'before' => '<div class="page-links">' . esc_html__('Pages:', 'india-day-trip'),
                                        'after'  => '</div>',
                                    )
                                );
                                ?>
                            </div><!-- .entry-content -->

                            <footer class="entry-footer">
                                <?php india_day_trip_entry_footer(); ?>
                            </footer><!-- .entry-footer -->
                        </article><!-- #post-<?php the_ID(); ?> -->

                        <?php
                        // Tour booking section
                        if ('tour' === get_post_type()) :
                        ?>
                            <div class="tour-booking-section">
                                <div class="booking-card">
                                    <h3>Book This Tour</h3>
                                    <div class="booking-form">
                                        <a href="<?php echo home_url('/contact'); ?>" class="th-btn style3 th-icon">Contact Us to Book</a>
                                        <p class="booking-note">Get personalized quotes and availability information</p>
                                    </div>
                                </div>
                            </div>
                    <?php
                        endif;

                        // Post navigation
                        the_post_navigation(
                            array(
                                'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'india-day-trip') . '</span> <span class="nav-title">%title</span>',
                                'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'india-day-trip') . '</span> <span class="nav-title">%title</span>',
                            )
                        );

                        // If comments are open or we have at least one comment, load up the comment template.
                        if (comments_open() || get_comments_number()) :
                            comments_template();
                        endif;

                    endwhile; // End of the loop.
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
