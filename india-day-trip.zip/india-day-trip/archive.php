<?php

/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package India_Day_Trip
 */

get_header();
?>

<div class="breadcumb-wrapper" data-bg-src="<?php echo get_template_directory_uri(); ?>/assets/img/bg/breadcumb-bg.jpg">
    <div class="container">
        <div class="breadcumb-content">
            <h1 class="breadcumb-title">
                <?php
                if (is_category()) {
                    single_cat_title();
                } elseif (is_tag()) {
                    single_tag_title();
                } elseif (is_author()) {
                    the_author();
                } elseif (is_date()) {
                    echo get_the_date('F Y');
                } else {
                    post_type_archive_title();
                }
                ?>
            </h1>
            <ul class="breadcumb-menu">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li>
                    <?php
                    if (is_category()) {
                        single_cat_title();
                    } elseif (is_tag()) {
                        single_tag_title();
                    } elseif (is_author()) {
                        the_author();
                    } elseif (is_date()) {
                        echo get_the_date('F Y');
                    } else {
                        post_type_archive_title();
                    }
                    ?>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="space-top space-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="archive-content">
                    <?php if (have_posts()) : ?>

                        <header class="page-header">
                            <?php
                            the_archive_title('<h1 class="page-title">', '</h1>');
                            the_archive_description('<div class="archive-description">', '</div>');
                            ?>
                        </header><!-- .page-header -->

                        <?php
                        /* Start the Loop */
                        while (have_posts()) :
                            the_post();
                        ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class('archive-post'); ?>>
                                <div class="post-thumbnail">
                                    <?php india_day_trip_post_thumbnail(); ?>
                                </div>
                                <header class="entry-header">
                                    <?php
                                    if (is_singular()) :
                                        the_title('<h1 class="entry-title">', '</h1>');
                                    else :
                                        the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
                                    endif;
                                    ?>
                                </header><!-- .entry-header -->

                                <div class="entry-content">
                                    <?php
                                    if (is_singular()) {
                                        the_content();
                                    } else {
                                        the_excerpt();
                                    ?>
                                        <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
                                    <?php
                                    }
                                    ?>
                                </div><!-- .entry-content -->

                                <footer class="entry-footer">
                                    <?php india_day_trip_entry_footer(); ?>
                                </footer><!-- .entry-footer -->
                            </article><!-- #post-<?php the_ID(); ?> -->
                    <?php
                        endwhile;

                        the_posts_navigation();

                    else :

                        get_template_part('template-parts/content', 'none');

                    endif;
                    ?>
                </div>
            </div>
            <div class="col-lg-4">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
