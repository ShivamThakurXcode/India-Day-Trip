# India Day Trip WordPress Theme

A premium WordPress theme for India Day Trip, an Agra-based tour and travel company specializing in Taj Mahal Tours, Golden Triangle Tours, and Same Day Tours.

## Description

India Day Trip Theme is a fully customizable WordPress theme designed specifically for tour and travel companies. It features a modern, responsive design with advanced functionality for showcasing tours, managing bookings, and providing an excellent user experience.

## Features

### Core Features
- **Responsive Design**: Mobile-first approach with perfect display on all devices
- **Custom Post Types**: Dedicated tour, gallery, and testimonial management
- **Advanced Navigation**: Multi-level menu system with mobile support
- **SEO Optimized**: Built-in SEO features and schema markup
- **Performance Focused**: Optimized assets and caching support

### Tour Management
- Custom Tour post type with pricing, duration, and location fields
- Tour categories and filtering
- Featured tours showcase
- Booking integration ready

### Content Management
- Gallery management with categories
- Testimonial system
- Blog integration
- Contact forms

### Design Features
- Bootstrap-based responsive framework
- Swiper.js sliders and carousels
- FontAwesome icons
- Custom color schemes
- Smooth animations

## Installation

1. Download the theme zip file
2. Go to WordPress Admin > Appearance > Themes
3. Click "Add New" and upload the theme
4. Activate the theme

## Required Plugins

### Essential Plugins
- **Advanced Custom Fields Pro** - For custom fields management
- **Contact Form 7** - For contact and booking forms
- **Yoast SEO** - For search engine optimization

### Recommended Plugins
- **WP Rocket** - Performance optimization
- **Smush** - Image optimization
- **UpdraftPlus** - Backup solution

## Setup Instructions

### 1. Install Required Plugins
After activating the theme, install and activate the required plugins listed above.

### 2. Create Essential Pages
Create the following pages in WordPress:
- Home (set as front page)
- About
- Tours
- Gallery
- Contact
- Privacy Policy
- Terms & Conditions

### 3. Set Up Menus
Create and assign menus:
- **Primary Menu**: Home, About, Tours (with sub-menu), Gallery, Contact
- **Footer Menu**: Privacy Policy, Terms & Conditions

### 4. Configure Custom Post Types
- Add tour packages using the Tour post type
- Upload gallery images
- Add customer testimonials

### 5. Theme Customization
- Go to Appearance > Customize
- Set site logo and colors
- Configure homepage sections

## Theme Structure

```
india-day-trip/
├── assets/                 # Theme assets (CSS, JS, images)
├── inc/                    # Include files
│   ├── custom-header.php
│   ├── customizer.php
│   ├── jetpack.php
│   ├── template-functions.php
│   └── template-tags.php
├── template-parts/         # Reusable template parts
├── functions.php           # Theme functions
├── header.php              # Header template
├── footer.php              # Footer template
├── index.php               # Homepage template
├── page.php                # Default page template
├── style.css               # Main stylesheet
├── screenshot.png          # Theme preview
└── README.md               # This file
```

## Customization

### Colors
The theme uses CSS custom properties for easy color customization:
```css
:root {
    --primary-color: #ff6b35;
    --secondary-color: #2d3748;
    --accent-color: #e53e3e;
}
```

### Layout
- Modify templates in the theme root
- Use child theme for major customizations
- Override styles in custom CSS

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Development

### Prerequisites
- WordPress 5.0+
- PHP 7.4+
- MySQL 5.6+

### Local Development
1. Set up local WordPress environment
2. Clone or download the theme
3. Activate the theme
4. Install required plugins
5. Start development

## Support

For support and customization requests:
- Email: info@indiadaytrip.com
- Website: https://indiadaytrip.com

## Changelog

### Version 1.0.0
- Initial release
- Complete theme conversion from static PHP site
- Custom post types for tours, galleries, testimonials
- Responsive design implementation
- SEO optimization features

## License

This theme is licensed under the GPL v2 or later.

## Credits

- **Bootstrap**: Responsive framework
- **Swiper**: Slider library
- **FontAwesome**: Icon library
- **Google Fonts**: Typography

---

**India Day Trip** - Your Trusted Travel Partner in Agra