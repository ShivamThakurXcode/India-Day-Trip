<?php

/**
 * India Day Trip Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package India_Day_Trip
 */

if (! defined('_S_VERSION')) {
    // Replace the version number of the theme on each release.
    define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function india_day_trip_setup()
{
    /*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		*/
    load_theme_textdomain('india-day-trip', get_template_directory() . '/languages');

    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    /*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
    add_theme_support('title-tag');

    /*
		* Enable support for Post Thumbnails on posts and pages.
		*/
    add_theme_support('post-thumbnails');

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus(
        array(
            'menu-1' => esc_html__('Primary', 'india-day-trip'),
            'footer-menu' => esc_html__('Footer Menu', 'india-day-trip'),
        )
    );

    /*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    // Set up the WordPress core custom background feature.
    add_theme_support(
        'custom-background',
        apply_filters(
            'india_day_trip_custom_background_args',
            array(
                'default-color' => 'ffffff',
                'default-image' => '',
            )
        )
    );

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');

    /**
     * Add support for core custom logo.
     */
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        )
    );
}
add_action('after_setup_theme', 'india_day_trip_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 */
function india_day_trip_content_width()
{
    $GLOBALS['content_width'] = apply_filters('india_day_trip_content_width', 640);
}
add_action('after_setup_theme', 'india_day_trip_content_width', 0);

/**
 * Register widget area.
 */
function india_day_trip_widgets_init()
{
    register_sidebar(
        array(
            'name'          => esc_html__('Sidebar', 'india-day-trip'),
            'id'            => 'sidebar-1',
            'description'   => esc_html__('Add widgets here.', 'india-day-trip'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action('widgets_init', 'india_day_trip_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function india_day_trip_scripts()
{
    // Styles
    wp_enqueue_style('india-day-trip-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), _S_VERSION);
    wp_enqueue_style('india-day-trip-fontawesome', get_template_directory_uri() . '/assets/css/fontawesome.min.css', array(), _S_VERSION);
    wp_enqueue_style('india-day-trip-magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.min.css', array(), _S_VERSION);
    wp_enqueue_style('india-day-trip-swiper', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), _S_VERSION);
    wp_enqueue_style('india-day-trip-style', get_template_directory_uri() . '/assets/css/style.css', array(), _S_VERSION);
    wp_enqueue_style('india-day-trip-main', get_stylesheet_uri(), array(), _S_VERSION);

    // Scripts
    wp_enqueue_script('jquery');
    wp_enqueue_script('india-day-trip-bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-swiper-js', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-magnific-popup-js', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-counterup', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-ui', get_template_directory_uri() . '/assets/js/jquery-ui.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-imagesloaded', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-isotope', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-gsap', get_template_directory_uri() . '/assets/js/gsap.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-circle-progress', get_template_directory_uri() . '/assets/js/circle-progress.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-matter', get_template_directory_uri() . '/assets/js/matter.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-matter-custom', get_template_directory_uri() . '/assets/js/matterjs-custom.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-nice-select', get_template_directory_uri() . '/assets/js/nice-select.min.js', array('jquery'), _S_VERSION, true);
    wp_enqueue_script('india-day-trip-main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), _S_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'india_day_trip_scripts');

// Register Custom Post Types
function india_day_trip_register_post_types()
{
    // Tour Custom Post Type
    register_post_type(
        'tour',
        array(
            'labels' => array(
                'name' => __('Tours'),
                'singular_name' => __('Tour')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'menu_icon' => 'dashicons-location-alt',
            'rewrite' => array('slug' => 'tours'),
        )
    );

    // Gallery Custom Post Type
    register_post_type(
        'gallery',
        array(
            'labels' => array(
                'name' => __('Gallery'),
                'singular_name' => __('Gallery Item')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-images-alt2',
            'rewrite' => array('slug' => 'gallery'),
        )
    );

    // Testimonial Custom Post Type
    register_post_type(
        'testimonial',
        array(
            'labels' => array(
                'name' => __('Testimonials'),
                'singular_name' => __('Testimonial')
            ),
            'public' => true,
            'has_archive' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-testimonial',
            'rewrite' => array('slug' => 'testimonial'),
        )
    );
}
add_action('init', 'india_day_trip_register_post_types');

// Register Taxonomies
function india_day_trip_register_taxonomies()
{
    // Tour Categories
    register_taxonomy('tour_category', 'tour', array(
        'labels' => array(
            'name' => __('Tour Categories'),
            'singular_name' => __('Tour Category')
        ),
        'hierarchical' => true,
        'rewrite' => array('slug' => 'tour-category'),
    ));

    // Gallery Categories
    register_taxonomy('gallery_category', 'gallery', array(
        'labels' => array(
            'name' => __('Gallery Categories'),
            'singular_name' => __('Gallery Category')
        ),
        'hierarchical' => true,
        'rewrite' => array('slug' => 'gallery-category'),
    ));
}
add_action('init', 'india_day_trip_register_taxonomies');

// Custom excerpt length
function india_day_trip_excerpt_length($length)
{
    return 20;
}
add_filter('excerpt_length', 'india_day_trip_excerpt_length', 999);

// Custom excerpt more
function india_day_trip_excerpt_more($more)
{
    return '...';
}
add_filter('excerpt_more', 'india_day_trip_excerpt_more');

// Add custom image sizes
add_image_size('tour-thumbnail', 400, 300, true);
add_image_size('gallery-large', 800, 600, true);
add_image_size('hero-image', 1920, 800, true);

// Primary menu fallback
function india_day_trip_primary_menu_fallback()
{
?>
    <ul>
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li><a href="<?php echo home_url('/about'); ?>">About</a></li>
        <li class="menu-item-has-children">
            <a href="#">Tours</a>
            <ul class="sub-menu">
                <li><a href="<?php echo home_url('/tours'); ?>">All Tours</a></li>
                <li><a href="<?php echo home_url('/tours?category=same-day'); ?>">Same Day Tours</a></li>
                <li><a href="<?php echo home_url('/tours?category=taj-mahal'); ?>">Taj Mahal Tours</a></li>
                <li><a href="<?php echo home_url('/tours?category=golden-triangle'); ?>">Golden Triangle Tours</a></li>
            </ul>
        </li>
        <li><a href="<?php echo home_url('/gallery'); ?>">Gallery</a></li>
        <li><a href="<?php echo home_url('/contact'); ?>">Contact Us</a></li>
    </ul>
<?php
}

// Remove admin bar for non-admin users on frontend
if (! current_user_can('administrator') && ! is_admin()) {
    show_admin_bar(false);
}

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
    require get_template_directory() . '/inc/jetpack.php';
}
