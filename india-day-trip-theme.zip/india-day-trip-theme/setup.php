<?php
// india-day-trip-theme/setup.php

/**
 * Theme Setup and Content Importer
 * This script runs on theme activation to create CPTs, pages, and import content.
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

function india_day_trip_setup_theme() {

    // Step 1: Register Custom Post Type "Tour"
    if (!post_type_exists('tour')) {
        $args = array(
            'public'             => true,
            'label'              => __('Tours', 'india-day-trip'),
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'tour'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-palmtree',
            'supports'           => array('title', 'editor', 'thumbnail', 'custom-fields'),
            'show_in_rest'       => true,
        );
        register_post_type('tour', $args);
        // Flush rewrite rules to make the new CPT's permalinks work
        flush_rewrite_rules();
    }

    // Step 2: Get content from our JSON file
    $json_file = get_template_directory() . '/content.json';
    if (!file_exists($json_file)) {
        return; // Exit if the JSON file doesn't exist
    }

    $content_data = json_decode(file_get_contents($json_file), true);
    if (is_null($content_data)) {
        return; // Exit if JSON is invalid
    }

    // Step 3: Create Pages
    if (isset($content_data['pages']) && is_array($content_data['pages'])) {
        foreach ($content_data['pages'] as $page_data) {
            // Check if page already exists by slug
            $existing_page = get_page_by_path($page_data['slug']);
            if (!$existing_page) {
                $page_id = wp_insert_post(array(
                    'post_title'   => wp_strip_all_tags($page_data['title']),
                    'post_name'    => $page_data['slug'],
                    'post_content' => $page_data['content'],
                    'post_status'  => 'publish',
                    'post_author'  => 1,
                    'post_type'    => 'page',
                    'page_template' => isset($page_data['template']) ? $page_data['template'] : 'default'
                ));
                // Optionally set static front page
                if ($page_data['slug'] === 'home') {
                    update_option('page_on_front', $page_id);
                    update_option('show_on_front', 'page');
                }
            }
        }
    }

    // Step 4: Create Tours (CPT Entries)
    if (isset($content_data['tours']) && is_array($content_data['tours'])) {
        foreach ($content_data['tours'] as $tour_data) {
            // Check if tour already exists by slug
            $existing_tour = get_page_by_path($tour_data['slug'], OBJECT, 'tour');
            if (!$existing_tour) {
                $tour_id = wp_insert_post(array(
                    'post_title'   => wp_strip_all_tags($tour_data['title']),
                    'post_name'    => $tour_data['slug'],
                    'post_content' => $tour_data['content'],
                    'post_status'  => 'publish',
                    'post_author'  => 1,
                    'post_type'    => 'tour',
                ));

                // Step 5: Add Custom Fields (Meta Data) to the Tour
                if ($tour_id && !is_wp_error($tour_id) && isset($tour_data['meta'])) {
                    foreach ($tour_data['meta'] as $key => $value) {
                        update_post_meta($tour_id, $key, $value);
                    }
                }
            }
        }
    }
}

// Hook into 'after_switch_theme' which fires only when the theme is activated
add_action('after_switch_theme', 'india_day_trip_setup_theme');

// Optional: Clean up if the theme is switched away
function india_day_trip_cleanup_theme() {
    // This is an example of how you could clean up, but be careful!
    // Uncommenting the line below would DELETE all 'tour' posts when the theme is deactivated.
    // Usually, you want to leave the content.
    // $tours = get_posts(array('post_type' => 'tour', 'numberposts' => -1));
    // foreach ($tours as $tour) {
    //     wp_delete_post($tour->ID, true); // true to force delete
    // }
}
// add_action('switch_theme', 'india_day_trip_cleanup_theme');