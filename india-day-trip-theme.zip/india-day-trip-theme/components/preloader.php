<div id="preloader" class="preloader">
    <div class="preloader-inner"><img src="assets/img/logo/logo-header.png" alt="" style="height: 60px; width: auto;"></div>
</div>