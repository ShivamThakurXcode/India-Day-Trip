<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <meta name="author" content="India Day Trip">
    <meta name="description"
        content="India Day Trip - Agra based tour and travel company offering Same Day Tours, Taj Mahal Tours, and Golden Triangle Tours">
    <meta name="keywords" content="India Day Trip, Agra tours, Taj Mahal tours, Golden Triangle tours, Same Day tours">
    <meta name="robots" content="INDEX,FOLLOW">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo esc_url(home_url('/')); ?>">
    <meta property="og:title" content="<?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?>">
    <meta property="og:description" content="India Day Trip - Agra based tour and travel company offering Same Day Tours, Taj Mahal Tours, and Golden Triangle Tours">
    <meta property="og:image" content="<?php echo get_template_directory_uri(); ?>/assets/img/hero/hero-agra.webp">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo esc_url(home_url('/')); ?>">
    <meta property="twitter:title" content="<?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?>">
    <meta property="twitter:description" content="India Day Trip - Agra based tour and travel company offering Same Day Tours, Taj Mahal Tours, and Golden Triangle Tours">
    <meta property="twitter:image" content="<?php echo get_template_directory_uri(); ?>/assets/img/hero/hero-agra.webp">

    <!-- links  -->
    <?php include 'components/links.php'; ?>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <!-- prelaoder -->
    <?php include 'components/preloader.php'; ?>
    <!-- sidemenu -->
    <?php include 'components/sidebar.php'; ?>

    <!-- popup search box -->
    <div class="popup-search-box"><button class="searchClose"><i class="fal fa-times"></i></button>
        <form action="#"><input type="text" placeholder="What are you looking for?"> <button type="submit"><i
                    class="fal fa-search"></i></button></form>
    </div>
    <div class="th-menu-wrapper onepage-nav">
        <div class="th-menu-area text-center"><button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo"><a href="<?php echo esc_url(home_url('/')); ?>"><img src="assets/img/logo/logo-header.webp"
                        alt="India Day Trip"></a>
            </div>
            <div class="th-mobile-menu">
                <ul>
                    <li><a class="active" href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url(home_url('/about')); ?>">About</a></li>
                    <li class="menu-item-has-children"><a href="#">Tours</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo esc_url(home_url('/same-day-tours')); ?>">Same Day Tours</a></li>
                            <li><a href="<?php echo esc_url(home_url('/taj-mahal-tours')); ?>">Taj Mahal Tours</a></li>
                            <li><a href="<?php echo esc_url(home_url('/golden-triangle-tours')); ?>">Golden Triangle Tours</a></li>
                            <li><a href="<?php echo esc_url(home_url('/agra-tours')); ?>">Agra Tours</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo esc_url(home_url('/gallery')); ?>">Gallery</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>


    <!-- header  -->

    <?php include 'components/header.php'; ?>