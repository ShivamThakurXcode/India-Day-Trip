<?php
// functions.php

function india_day_trip_enqueue_scripts() {
    // Enqueue Styles
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
    wp_enqueue_style('fontawesome-css', get_template_directory_uri() . '/assets/css/fontawesome.min.css');
    wp_enqueue_style('magnific-popup-css', get_template_directory_uri() . '/assets/css/magnific-popup.min.css');
    wp_enqueue_style('swiper-css', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css');
    wp_enqueue_style('india-day-trip-style', get_stylesheet_uri()); // Enqueues the main style.css

    // Enqueue Scripts
    wp_enqueue_script('jquery'); // Use WordPress built-in jQuery
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), null, true);
    wp_enqueue_script('circle-progress-js', get_template_directory_uri() . '/assets/js/circle-progress.js', array('jquery'), null, true);
    wp_enqueue_script('gsap-js', get_template_directory_uri() . '/assets/js/gsap.min.js', array(), null, true);
    wp_enqueue_script('imagesloaded-js', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array(), null, true);
    wp_enqueue_script('isotope-js', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array(), null, true);
    wp_enqueue_script('jquery-ui-js', get_template_directory_uri() . '/assets/js/jquery-ui.min.js', array('jquery'), null, true);
    wp_enqueue_script('jquery-counterup-js', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', array('jquery'), null, true);
    wp_enqueue_script('magnific-popup-js', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), null, true);
    wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('matter-js', get_template_directory_uri() . '/assets/js/matter.min.js', array(), null, true);
    wp_enqueue_script('matterjs-custom-js', get_template_directory_uri() . '/assets/js/matterjs-custom.js', array('matter-js'), null, true);
    wp_enqueue_script('nice-select-js', get_template_directory_uri() . '/assets/js/nice-select.min.js', array('jquery'), null, true);
    wp_enqueue_script('swiper-js', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'india_day_trip_enqueue_scripts');

// Include the theme setup and content importer
require_once get_template_directory() . '/setup.php';